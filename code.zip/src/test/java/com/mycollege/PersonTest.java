package com.mycollege;

public class PersonTest {
}
